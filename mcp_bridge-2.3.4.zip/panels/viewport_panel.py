"""3D Viewport sidebar panel: real clickable buttons for the two actions
worth triggering without going through an MCP client -- creating a scene
checkpoint and regenerating localized structural names. Both operators call
the exact same ToolBase.execute() the MCP bridge itself dispatches to (via
TOOL_REGISTRY), so there is no second implementation of either to drift out
of sync with the MCP-facing one.
"""

import sys
import threading
import time
from pathlib import Path
import tempfile
import urllib.parse

import bpy

from ..tools import TOOL_REGISTRY
from ..tools.language_vocabularies import LANGUAGE_ITEMS
from .preferences import status_text_and_icon

# Clipboard-to-image support for the AI Generate dialog. Priority order:
# 1. clipboard *text* that names an existing image file (incl. file:// URLs),
# 2. copied files from Explorer (CF_HDROP, Windows),
# 3. an actual bitmap on the clipboard, e.g. a screenshot (CF_DIB, Windows).
# The DIB case needs a conversion because providers accept PNG/JPG/WebP but
# the OS hands over a raw device-independent bitmap; it's wrapped into a BMP
# (header + payload verbatim) and re-encoded to PNG through Blender's own
# image loader, which keeps the whole thing dependency-free.
_AI_CLIPBOARD_IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".webp")


def _dib_to_png(dib: bytes, dest_png: Path) -> Path | None:
    """Wrap a CF_DIB / CF_DIBV5 payload into a BMP file and re-encode it as
    PNG via Blender's image loader. Must run on the main thread (bpy.data)."""
    import struct

    try:
        hdr_size = struct.unpack_from("<I", dib, 0)[0]
        bpp = struct.unpack_from("<H", dib, 14)[0]
        compression = struct.unpack_from("<I", dib, 16)[0]
        clr_used = struct.unpack_from("<I", dib, 32)[0]
        palette = clr_used * 4 if clr_used else ((1 << bpp) * 4 if bpp <= 8 else 0)
        offset = 14 + hdr_size + palette
        # BITMAPV4/V5 headers already carry the BI_BITFIELDS channel masks;
        # only the classic 40-byte header stores them as a trailing extension.
        if compression == 3 and hdr_size < 108:
            offset += 12
        bmp_path = dest_png.with_suffix(".bmp")
        dest_png.parent.mkdir(parents=True, exist_ok=True)
        bmp_path.write_bytes(struct.pack("<2sIHHI", b"BM", 14 + len(dib), 0, 0, offset) + dib)

        img = bpy.data.images.load(str(bmp_path), check_existing=False)
    except Exception:
        return None
    try:
        img.filepath_raw = str(dest_png)
        img.file_format = "PNG"
        img.save()
        return dest_png
    except Exception:
        return None
    finally:
        bpy.data.images.remove(img)
        bmp_path.unlink(missing_ok=True)


_KNOWN_CLIPBOARD_FORMATS = {
    1: "TEXT", 2: "BITMAP", 8: "DIB", 13: "UNICODETEXT", 15: "HDROP", 17: "DIBV5",
}


def _describe_clipboard_formats(user32) -> str:
    """Human-readable list of everything currently on the clipboard -- this is
    what the paste button reports when no format it understands is present,
    so 'no usable image' is never a silent guess."""
    import ctypes

    fmts = []
    fmt = 0
    while True:
        fmt = user32.EnumClipboardFormats(fmt)
        if not fmt:
            break
        name_buf = ctypes.create_unicode_buffer(128)
        name = (
            name_buf.value
            if user32.GetClipboardFormatNameW(fmt, name_buf, 128)
            else _KNOWN_CLIPBOARD_FORMATS.get(fmt, "?")
        )
        fmts.append(f"{name}({fmt})")
    return ", ".join(fmts) if fmts else "(empty)"


def _open_clipboard_with_retry(user32, attempts: int = 6, delay_s: float = 0.08) -> bool:
    """The clipboard can be momentarily owned by the app that just wrote it
    (e.g. Snipping Tool right after a capture); a short retry loop turns that
    race from a hard fail into a sub-second wait."""
    for i in range(attempts):
        if user32.OpenClipboard(0):
            return True
        time.sleep(delay_s)
    return False


def _windows_clipboard_image(dest_dir: Path) -> tuple[Path | None, str]:
    """Returns (image_path | None, diagnostics-for-the-failure-case).

    Priority: Explorer-copied files (CF_HDROP), then Snipping Tool's native
    lossless "PNG" registered format (raw PNG bytes -- no conversion needed),
    then CF_DIB / CF_DIBV5 device-independent bitmaps wrapped into a BMP and
    re-encoded via Blender's image loader."""
    import ctypes

    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32
    kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
    kernel32.GlobalLock.restype = ctypes.c_void_p
    kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
    kernel32.GlobalSize.argtypes = [ctypes.c_void_p]
    kernel32.GlobalSize.restype = ctypes.c_size_t
    user32.GetClipboardData.restype = ctypes.c_void_p

    found = None
    if not _open_clipboard_with_retry(user32):
        return None, "could not open the clipboard (held by another process)"
    try:
        CF_HDROP, CF_DIB, CF_DIBV5 = 15, 8, 17
        png_format = user32.RegisterClipboardFormatW("PNG")

        if user32.IsClipboardFormatAvailable(CF_HDROP):
            handle = user32.GetClipboardData(CF_HDROP)
            if handle:
                shell32 = ctypes.windll.shell32
                shell32.DragQueryFileW.argtypes = [
                    ctypes.c_void_p, ctypes.c_uint, ctypes.c_wchar_p, ctypes.c_uint
                ]
                count = shell32.DragQueryFileW(handle, 0xFFFFFFFF, None, 0)
                for i in range(count):
                    buf = ctypes.create_unicode_buffer(1024)
                    shell32.DragQueryFileW(handle, i, buf, len(buf))
                    candidate = Path(buf.value)
                    if candidate.suffix.lower() in _AI_CLIPBOARD_IMAGE_EXTS and candidate.is_file():
                        found = candidate
                        break

        if found is None:
            for fmt, label in ((png_format, "PNG"), (CF_DIB, "CF_DIB"), (CF_DIBV5, "CF_DIBV5")):
                if not fmt or not user32.IsClipboardFormatAvailable(fmt):
                    continue
                handle = user32.GetClipboardData(fmt)
                if not handle:
                    continue
                ptr = kernel32.GlobalLock(handle)
                if not ptr:
                    continue
                try:
                    payload = ctypes.string_at(ptr, kernel32.GlobalSize(ptr))
                finally:
                    kernel32.GlobalUnlock(ptr)

                dest_dir.mkdir(parents=True, exist_ok=True)
                if label == "PNG":
                    # Raw PNG straight off the clipboard -- just write it.
                    out = dest_dir / "clipboard.png"
                    out.write_bytes(payload)
                    found = out if payload[:8] == b"\x89PNG\r\n\x1a\n" else None
                else:
                    found = _dib_to_png(payload, dest_dir / "clipboard.png")
                if found is not None:
                    break

        if found is None:
            return None, f"no image format recognized (clipboard has: {_describe_clipboard_formats(user32)})"
        return found, ""
    finally:
        user32.CloseClipboard()


def find_clipboard_image() -> tuple["Path | None", str]:
    """Returns (image_path_or_None, diagnostic_message_for_failure)."""
    text = bpy.context.window_manager.clipboard.strip().strip('"')
    if text:
        if text.lower().startswith("file:///"):
            text = urllib.parse.unquote(text[len("file://"):])
        candidate = Path(text)
        if candidate.suffix.lower() in _AI_CLIPBOARD_IMAGE_EXTS and candidate.is_file():
            return candidate, ""

    if sys.platform == "win32":
        return _windows_clipboard_image(Path(tempfile.gettempdir()) / "mcp_blender_clipboard")

    return None, "clipboard image paste is currently implemented on Windows only"


class MCP_OT_paste_image(bpy.types.Operator):
    bl_idname = "mcp_bridge.paste_image"
    bl_label = "Paste from Clipboard"
    bl_description = (
        "Fill the Image field from the clipboard: a copied image file, an image "
        "path copied as text, or a screenshot bitmap (screenshots are converted "
        "to a temporary PNG)"
    )

    def execute(self, context):
        found, diagnostics = find_clipboard_image()
        if found is None:
            self.report({"ERROR"}, f"No usable image in the clipboard: {diagnostics}")
            return {"CANCELLED"}

        # Hand-off via a WindowManager custom property rather than reaching
        # into window.modal_operators: props-dialog operator instances aren't
        # reliably discoverable/matchable there, while the dialog's own next
        # redraw simply picks this up wherever the dialog happens to be.
        context.window_manager["mcp_clipboard_image"] = str(found)
        self.report({"INFO"}, f"Image pasted: {found.name}")
        return {"FINISHED"}


class MCP_OT_create_checkpoint(bpy.types.Operator):
    bl_idname = "mcp_bridge.create_checkpoint"
    bl_label = "Create Scene Checkpoint"
    bl_description = "Save a full scene snapshot to disk that can be restored later"
    bl_options = {"REGISTER", "UNDO"}

    name: bpy.props.StringProperty(
        name="Name", description="Optional checkpoint name (auto-generated if empty)", default=""
    )

    def execute(self, context):
        if context.window:
            context.window.cursor_modal_set("WAIT")
        try:
            result = TOOL_REGISTRY["create_scene_checkpoint"].execute({"name": self.name or None})
            if not result.get("success"):
                self.report({"ERROR"}, result.get("message", "Checkpoint failed"))
                return {"CANCELLED"}
            self.report({"INFO"}, result["message"])
            return {"FINISHED"}
        finally:
            if context.window:
                context.window.cursor_modal_restore()


class MCP_OT_show_rename_result(bpy.types.Operator):
    bl_idname = "mcp_bridge.show_rename_result"
    bl_label = "Rename Result"
    bl_description = "Show which names were changed by the last Regenerate Names run"
    bl_options = {"REGISTER"}

    _pairs = None
    _message = ""

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=480)

    def draw(self, context):
        layout = self.layout
        pairs = MCP_OT_show_rename_result._pairs or []

        if not pairs:
            layout.label(text="Nothing needed renaming -- all names already matched vocabulary.", icon="INFO")
            return

        layout.label(text=f"OK, renamed {len(pairs)} name(s):", icon="CHECKMARK")

        # Literal "old1, old2, ... -> new1, new2, ..." summary, wrapped so it
        # doesn't run off the dialog on hierarchies with many renamed parts.
        box_summary = layout.box()
        chunk = 6
        for i in range(0, len(pairs), chunk):
            group = pairs[i:i + chunk]
            olds = ", ".join(p["old"] for p in group)
            news = ", ".join(p["new"] for p in group)
            box_summary.label(text=f"{olds}  ->  {news}")

        layout.separator()
        box_table = layout.box()
        for p in pairs:
            row = box_table.row()
            row.label(text=p["old"], icon="OUTLINER_OB_MESH")
            row.label(text="->", icon="FORWARD")
            row.label(text=p["new"])

    def execute(self, context):
        return {"FINISHED"}


REORG_LEVEL_ITEMS = [
    ("LIGHT", "Light (minimal changes)", "Only fix clearly generic/garbled names, leave the rest alone -- fewer, coarser groups when separating", "TRIA_DOWN", 0),
    ("STANDARD", "Standard", "Balanced renaming/regrouping", "DOT", 1),
    ("DEEP", "Deep (thorough reorg)", "Rename/reorganize as much as possible -- finer, more granular groups when separating", "TRIA_UP", 2),
]


SPLIT_METHOD_ITEMS = [
    ("auto", "Auto (loose, material, vision, creases)", "Try loose parts, then material, then the vision LLM, then fall back to a crease split for single connected meshes", "AUTOMERGE_ON", 0),
    ("loose", "Loose parts", "Split only by disconnected geometry", "MESH_DATA", 1),
    ("material", "Material", "Split only by material slots", "MATERIAL", 2),
    ("vision", "Vision LLM", "A vision model decides the logical areas from a multiview render; geometry only cuts the boundaries", "HIDE_OFF", 3),
    ("crease", "Creases", "Cut along edges sharper than the angle below, duplicating border vertices", "EDGESEL", 4),
]


class MCP_SeparatePartItem(bpy.types.PropertyGroup):
    """One staged part awaiting confirmation: checkbox + Blender-assigned name."""
    name: bpy.props.StringProperty(name="Part")
    keep: bpy.props.BoolProperty(name="Keep", default=True)


# Staged confirmation state, filled by MCP_OT_separate_logical_areas when it
# runs with require_confirmation and read back by the confirm dialog's invoke.
# Single slot is enough: Blender's props dialogs are modal-ish and a second
# split run simply restages.
_SEPARATE_CONFIRM_STATE: dict = {}


class MCP_OT_regen_names(bpy.types.Operator):
    bl_idname = "mcp_bridge.regen_names"
    bl_label = "Regenerate Names..."
    bl_description = (
        "Rename selected objects/hierarchy, active collection, or scene into clean localized vocabulary "
        "and re-link children/objects in alphabetical order"
    )
    bl_options = {"REGISTER", "UNDO"}

    scope: bpy.props.EnumProperty(
        name="Scope",
        description="Target elements to rename",
        items=[
            ("SELECTED", "Selected Object(s) & Hierarchy", "Rename selected objects and their children parts", "RESTRICT_SELECT_OFF", 0),
            ("ACTIVE_COLLECTION", "Active Collection", "Rename active collection and its contents", "GROUP", 1),
            ("SCENE", "Entire Scene", "Rename all scene collections and objects", "WORLD", 2),
        ],
        default="SELECTED",
    )

    lang: bpy.props.EnumProperty(
        name="Language",
        description="Target language vocabulary",
        items=LANGUAGE_ITEMS,
        default="it",
    )

    rename_meshes: bpy.props.BoolProperty(
        name="Rename Mesh Data",
        description="Keep underlying mesh data blocks synchronized with object names",
        default=True,
    )

    use_llm: bpy.props.BoolProperty(
        name="Use LLM Semantics",
        description="Call an LLM (via OPENROUTER_API_KEY in .env) to translate and organize hierarchy organically",
        default=True,
    )

    reorg_level: bpy.props.EnumProperty(
        name="Reorg Level",
        description="How aggressively the LLM should rename things (only applies with Use LLM Semantics)",
        items=REORG_LEVEL_ITEMS,
        default="STANDARD",
    )

    custom_prompt: bpy.props.StringProperty(
        name="Custom Instructions",
        description=(
            "Optional free-text instructions passed to the LLM (e.g. 'use nautical terms', "
            "'only rename hardware parts') -- only applies with Use LLM Semantics"
        ),
        default="",
    )

    use_vision: bpy.props.BoolProperty(
        name="Vision-Assisted Mesh Naming",
        description=(
            "After the structural/LLM pass, capture a close-up render of each remaining generic mesh "
            "leaf (e.g. 'Chair_Mesh') and ask a vision model (via OPENROUTER_API_KEY in .env) to name it "
            "by semantic role -- slower and one extra API call per mesh"
        ),
        default=False,
    )

    max_vision_renames: bpy.props.IntProperty(
        name="Max Vision Renames",
        description="Cap on how many mesh objects get a vision-assisted rename per run, to bound cost/time",
        default=9999,
        min=0,
        max=9999,
    )

    vision_only_generic: bpy.props.BoolProperty(
        name="Only Still-Generic Names",
        description=(
            "Only run the vision pass on mesh leaves the structural/LLM pass left untouched "
            "(still-generic exporter names like 'Cube.003', or names with no vocabulary match like "
            "'Chair_Mesh') instead of re-naming every mesh -- fewer renders/API calls"
        ),
        default=True,
    )

    def invoke(self, context, event):
        # Default scope intelligently based on active viewport selection
        if context.selected_objects:
            self.scope = "SELECTED"
        elif context.collection and context.collection != context.scene.collection:
            self.scope = "ACTIVE_COLLECTION"
        else:
            self.scope = "SCENE"
        return context.window_manager.invoke_props_dialog(self, width=380)

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="Regenerate & Localize Names", icon="WORLD")
        box.prop(self, "scope")
        box.prop(self, "lang")

        if self.scope == "SELECTED":
            count = len(context.selected_objects)
            if count > 0:
                names_preview = ", ".join([o.name for o in context.selected_objects[:3]])
                if count > 3:
                    names_preview += f"... (+{count - 3} more)"
                box.label(text=f"Selected ({count}): {names_preview}", icon="OBJECT_DATA")
            else:
                box.label(text="No objects selected! (Select in 3D View)", icon="ERROR")

        elif self.scope == "ACTIVE_COLLECTION":
            active_col = context.collection.name if context.collection else "None"
            box.label(text=f"Active Collection: {active_col}", icon="GROUP")

        layout.separator()
        box_opt = layout.box()
        box_opt.prop(self, "rename_meshes")
        box_opt.prop(self, "use_llm")
        if self.use_llm:
            box_opt.prop(self, "reorg_level")
            box_opt.prop(self, "custom_prompt", icon="TEXT")

        layout.separator()
        box_vision = layout.box()
        box_vision.prop(self, "use_vision")
        if self.use_vision:
            box_vision.prop(self, "vision_only_generic")
            box_vision.prop(self, "max_vision_renames")

    def execute(self, context):
        params = {
            "lang": self.lang,
            "rename_meshes": self.rename_meshes,
            "use_llm": self.use_llm,
            "reorg_level": self.reorg_level,
            "custom_prompt": self.custom_prompt,
            "use_vision": self.use_vision,
            "max_vision_renames": self.max_vision_renames,
            "vision_only_generic": self.vision_only_generic,
        }

        if self.scope == "SELECTED":
            selected = [obj.name for obj in context.selected_objects]
            if not selected:
                if context.active_object:
                    selected = [context.active_object.name]
                else:
                    self.report({"WARNING"}, "No objects selected in viewport")
                    return {"CANCELLED"}
            params["objects"] = selected

        elif self.scope == "ACTIVE_COLLECTION":
            if context.collection:
                params["element"] = context.collection.name
            else:
                params["element"] = None
        else:
            params["element"] = None

        if context.window:
            context.window.cursor_modal_set("WAIT")
        try:
            result = TOOL_REGISTRY["regen_element_names"].execute(params)
            if not result.get("success"):
                self.report({"ERROR"}, result.get("message", "Regen failed"))
                return {"CANCELLED"}

            report_msg = result["message"]
            if result.get("vision_note"):
                report_msg += f" ({result['vision_note']})"
            elif result.get("vision_used"):
                report_msg += f" + {len(result.get('vision_renames', []))} vision-assisted rename(s)"
            self.report({"INFO"}, report_msg)
            MCP_OT_show_rename_result._pairs = result.get("renamed_pairs", [])
            MCP_OT_show_rename_result._message = result["message"]
            try:
                # execute() re-runs (re-billing the LLM call) whenever the user
                # tweaks this operator's redo panel, and invoking another
                # operator's dialog from inside that restricted redo context
                # can raise RuntimeError -- the rename itself already
                # succeeded, so don't let a dialog failure surface as a crash.
                bpy.ops.mcp_bridge.show_rename_result("INVOKE_DEFAULT")
            except RuntimeError:
                pass
            return {"FINISHED"}
        finally:
            if context.window:
                context.window.cursor_modal_restore()


class MCP_OT_confirm_separated_parts(bpy.types.Operator):
    bl_idname = "mcp_bridge.confirm_separated_parts"
    bl_label = "Confirm Separated Parts"
    bl_description = (
        "Review every separated object from the staged split (keep/drop each one) "
        "and only then classify, rename, and organize the kept parts"
    )
    bl_options = {"REGISTER", "UNDO"}

    pending_id: bpy.props.StringProperty(name="Pending ID", default="")
    parts: bpy.props.CollectionProperty(type=MCP_SeparatePartItem)

    def invoke(self, context, event):
        state = _SEPARATE_CONFIRM_STATE
        if not state.get("pending_id") or not state.get("parts"):
            self.report({"ERROR"}, "No staged separation to confirm -- run Separate first.")
            return {"CANCELLED"}
        self.pending_id = state["pending_id"]
        raw_names = [str(p.get("name", "")) for p in state["parts"]]
        state["raw_names"] = raw_names
        self.parts.clear()
        for p in state["parts"]:
            item = self.parts.add()
            name = str(p.get("name", ""))
            suggested = str(p.get("suggested_name") or "")
            item.name = f"{name}  ->  {suggested}" if suggested and suggested != name else name
            item.keep = True
        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        layout = self.layout
        layout.label(text="Keep or drop each separated object:", icon="CHECKMARK")
        box = layout.box()
        for item in self.parts:
            row = box.row()
            row.prop(item, "keep", text="")
            row.label(text=item.name)
        layout.label(text="Dropped parts are deleted; kept parts are organized.", icon="INFO")

    def execute(self, context):
        raw = list(_SEPARATE_CONFIRM_STATE.get("raw_names", []))
        keep = [raw[i] for i, item in enumerate(self.parts) if item.keep and i < len(raw)]
        if not keep:
            self.report({"ERROR"}, "Nothing kept -- every part would be dropped.")
            return {"CANCELLED"}
        if context.window:
            context.window.cursor_modal_set("WAIT")
        try:
            result = TOOL_REGISTRY["confirm_separated_parts"].execute(
                {"pending_id": self.pending_id, "keep": keep}
            )
            if not result.get("success"):
                self.report({"ERROR"}, result.get("message", "Confirm failed"))
                return {"CANCELLED"}
            _SEPARATE_CONFIRM_STATE.clear()
            self.report({"INFO"}, result["message"])
            MCP_OT_show_separate_result._result = result
            try:
                bpy.ops.mcp_bridge.show_separate_result("INVOKE_DEFAULT")
            except RuntimeError:
                pass
            return {"FINISHED"}
        finally:
            if context.window:
                try:
                    context.window.cursor_modal_restore()
                except Exception:
                    pass


class MCP_OT_show_separate_result(bpy.types.Operator):
    bl_idname = "mcp_bridge.show_separate_result"
    bl_label = "Separation Result"
    bl_description = "Show the macro/medium/micro breakdown produced by the last Separate in Logical Areas run"
    bl_options = {"REGISTER"}

    _result = None

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=480)

    def draw(self, context):
        layout = self.layout
        result = MCP_OT_show_separate_result._result or {}
        groups = result.get("groups", [])

        if not groups:
            layout.label(text="No groups were produced.", icon="ERROR")
            return

        total_parts = sum(len(g["parts"]) for g in groups)
        classified_by = "LLM" if result.get("used_llm") else "heuristic clustering (no OPENROUTER_API_KEY)"
        layout.label(
            text=f"OK, separated into {len(groups)} group(s) / {total_parts} part(s) via {classified_by}:",
            icon="CHECKMARK",
        )

        for g in groups:
            box = layout.box()
            box.label(text=g["group"], icon="EMPTY_AXIS")
            col = box.column()
            col.scale_y = 0.9
            # Wrap long part lists instead of one label running off the dialog
            chunk = 4
            parts = g["parts"] or ["(no parts)"]
            for i in range(0, len(parts), chunk):
                col.label(text=", ".join(parts[i:i + chunk]))

    def execute(self, context):
        return {"FINISHED"}


class MCP_OT_separate_logical_areas(bpy.types.Operator):
    bl_idname = "mcp_bridge.separate_logical_areas"
    bl_label = "Separate in Logical Areas..."
    bl_description = (
        "Analyze the selected mesh(es) -- combining multiple selected objects into one working mesh first -- "
        "separate into logical parts (loose parts, materials, or creases), and organize them under parent "
        "Empties as macro/medium/micro areas using semantic classification (LLM via OPENROUTER_API_KEY in "
        ".env). The crease cutter accepts duplicated border vertices to break up a single connected mesh. "
        "Every separated part stays visible; the original source is renamed with a '.bak' suffix and hidden "
        "instead of deleted."
    )
    bl_options = {"REGISTER", "UNDO"}

    lang: bpy.props.EnumProperty(
        name="Language",
        description="Target language vocabulary",
        items=LANGUAGE_ITEMS,
        default="it",
    )

    reorg_level: bpy.props.EnumProperty(
        name="Reorg Level",
        description="How fine-grained the sub-assembly breakdown should be -- applies both to LLM classification and the no-LLM spatial-clustering fallback",
        items=REORG_LEVEL_ITEMS,
        default="STANDARD",
    )

    custom_prompt: bpy.props.StringProperty(
        name="Custom Instructions",
        description=(
            "Optional free-text instructions passed to the LLM (e.g. 'separate hinges and glass into "
            "their own group', 'ignore screws') -- only applies when OPENROUTER_API_KEY is configured"
        ),
        default="",
    )

    split_method: bpy.props.EnumProperty(
        name="Split Method",
        description="How the cutter breaks the working mesh into parts",
        items=SPLIT_METHOD_ITEMS,
        default="auto",
    )

    sharp_angle: bpy.props.FloatProperty(
        name="Crease Angle",
        description="Cut along edges sharper than this dihedral angle in degrees (auto fallback and crease method)",
        default=45.0,
        min=1.0,
        max=179.0,
    )

    target_parts: bpy.props.IntProperty(
        name="Target Parts",
        description="Merge crease fragments until this many parts (0 = off; min_part_faces is used instead)",
        default=0,
        min=0,
        max=100000,
    )

    min_part_faces: bpy.props.IntProperty(
        name="Min Part Faces",
        description="Merge crease fragments until every part reaches this many faces (0 = about 2% of faces)",
        default=0,
        min=0,
        max=100000000,
    )

    create_checkpoint: bpy.props.BoolProperty(
        name="Snapshot Before Separate",
        description="Save a scene checkpoint first so each separate run stays comparable and restorable",
        default=True,
    )

    require_confirmation: bpy.props.BoolProperty(
        name="Confirm Every Part",
        description="Stop after the cut and confirm each separated object (keep/drop) before anything is classified, renamed, or organized",
        default=True,
    )

    use_vision: bpy.props.BoolProperty(
        name="Vision-Assisted Part Naming",
        description=(
            "After classification, capture a close-up render of each part and ask a vision model (via "
            "OPENROUTER_API_KEY in .env) to name it by semantic role within its sub-assembly -- slower "
            "and one extra API call per part"
        ),
        default=False,
    )

    max_vision_renames: bpy.props.IntProperty(
        name="Max Vision Renames",
        description="Cap on how many parts get a vision-assisted rename per run, to bound cost/time",
        default=9999,
        min=0,
        max=9999,
    )

    vision_only_generic: bpy.props.BoolProperty(
        name="Only Generic Part Names",
        description=(
            "Only run the vision pass on parts that fell back to a generic 'Part_N' name (the LLM/heuristic "
            "classifier didn't give them a specific one) instead of re-naming every part -- fewer renders/API calls"
        ),
        default=True,
    )

    def invoke(self, context, event):
        mesh_objs = [o for o in context.selected_objects if o.type == "MESH"]
        if not mesh_objs:
            self.report({"ERROR"}, "Please select at least one MESH object in the 3D viewport first.")
            return {"CANCELLED"}
        return context.window_manager.invoke_props_dialog(self, width=380)

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="Separate Mesh in Logical Areas", icon="MESH_DATA")
        box.prop(self, "lang")

        mesh_objs = [o for o in context.selected_objects if o.type == "MESH"]
        if not mesh_objs and context.active_object and context.active_object.type == "MESH":
            mesh_objs = [context.active_object]

        if mesh_objs:
            count = len(mesh_objs)
            names_preview = ", ".join(o.name for o in mesh_objs[:3])
            if count > 3:
                names_preview += f"... (+{count - 3} more)"
            if count > 1:
                box.label(text=f"Selected ({count}, will be combined): {names_preview}", icon="OBJECT_DATA")
            else:
                box.label(text=f"Selected: {names_preview}", icon="OBJECT_DATA")
        else:
            box.label(text="No mesh selected! (Select in 3D View)", icon="ERROR")

        layout.separator()
        box_opt = layout.box()
        box_opt.prop(self, "reorg_level")
        box_opt.prop(self, "custom_prompt", icon="TEXT")
        box_opt.prop(self, "split_method")
        if self.split_method in {"auto", "crease"}:
            box_opt.prop(self, "sharp_angle")
            box_opt.prop(self, "target_parts")
            box_opt.prop(self, "min_part_faces")
        box_opt.prop(self, "create_checkpoint")
        box_opt.prop(self, "require_confirmation")

        layout.separator()
        box_vision = layout.box()
        box_vision.prop(self, "use_vision")
        if self.use_vision:
            box_vision.prop(self, "vision_only_generic")
            box_vision.prop(self, "max_vision_renames")

    def execute(self, context):
        params = {
            "lang": self.lang,
            "reorg_level": self.reorg_level,
            "custom_prompt": self.custom_prompt,
            "split_method": self.split_method,
            "sharp_angle": self.sharp_angle,
            "target_parts": self.target_parts,
            "min_part_faces": self.min_part_faces,
            "create_checkpoint": self.create_checkpoint,
            "split_only": bool(self.require_confirmation),
            "use_vision": self.use_vision,
            "max_vision_renames": self.max_vision_renames,
            "vision_only_generic": self.vision_only_generic,
        }

        if context.window:
            context.window.cursor_modal_set("WAIT")
        try:
            result = TOOL_REGISTRY["separate_logical_areas"].execute(params)
            if not result.get("success"):
                self.report({"ERROR"}, result.get("message", "Separation failed"))
                return {"CANCELLED"}

            if result.get("pending_confirmation"):
                # Stage the per-part confirmation dialog: nothing is classified
                # or organized yet, so the user reviews every separated object
                # first. The staged pieces are already selected in the viewport.
                _SEPARATE_CONFIRM_STATE.clear()
                _SEPARATE_CONFIRM_STATE.update({
                    "pending_id": result.get("pending_id"),
                    "parts": result.get("parts", []),
                    "message": result.get("message", ""),
                })
                self.report({"INFO"}, result.get("message", "Split staged -- confirm parts"))
                try:
                    bpy.ops.mcp_bridge.confirm_separated_parts("INVOKE_DEFAULT")
                except RuntimeError:
                    pass
                return {"FINISHED"}

            self.report({"INFO"}, result["message"])
            MCP_OT_show_separate_result._result = result
            try:
                # Same redo-panel caveat as MCP_OT_regen_names.execute(): the
                # separation already succeeded, so a dialog failure here
                # shouldn't surface as a crash.
                bpy.ops.mcp_bridge.show_separate_result("INVOKE_DEFAULT")
            except RuntimeError:
                pass
            return {"FINISHED"}
        finally:
            if context.window:
                context.window.cursor_modal_restore()


# Skipped by default by the invoke-smoke-test in MCP_OT_verify_tools:
# render/bake/batch/fluid tools can legitimately take real time even with no
# target object, so blindly calling them from a health check would make
# "Verify Tools" itself slow and unpredictable. prune_jobs is skipped too:
# with {} params it would really delete the user's finished jobs older than
# a day -- a side effect no health check should have. Everything else is expected
# (see ToolBase's own docstring contract) to validate required params and
# return a clean {"success": False, ...} before doing any real work -- so
# calling them with {} is a safe way to catch a tool that raises instead of
# validating. include_heavy opts into running these too, behind an explicit
# warning dialog (see draw()) since the user may want full coverage anyway.
_VERIFY_SKIP_KEYWORDS = ("render", "bake", "batch", "fluid", "prune")


class MCP_OT_verify_tools(bpy.types.Operator):
    bl_idname = "mcp_bridge.verify_tools"
    bl_label = "Verify Tools..."
    bl_description = (
        "Health-check every registered tool: confirms it's well-formed, then calls execute({}) "
        "in an isolated temporary scene (never your actual scene) to catch tools that raise an "
        "unhandled exception instead of cleanly validating missing input. Skips render/bake/"
        "batch/fluid/prune tools by default -- opt in via the dialog to include them too"
    )
    bl_options = {"REGISTER"}

    include_heavy: bpy.props.BoolProperty(
        name="Include Heavy Tools (render/bake/batch/fluid/prune)",
        description="Also run render/bake/batch/fluid/prune tools -- can take noticeably longer (prune really deletes old finished jobs)",
        default=False,
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "include_heavy")
        if self.include_heavy:
            col = layout.column()
            col.alert = True
            col.label(text="Warning: render/bake/batch/fluid tools will run for real,", icon="ERROR")
            col.label(text="in the isolated temp scene -- this can take noticeably longer.")
            col.label(text="prune_jobs will really delete old finished jobs.", icon="ERROR")

    def execute(self, context):
        from ..tools.progress_hud_ops import push_hud_update

        malformed = []
        for name, tool in TOOL_REGISTRY.items():
            if not getattr(tool, "name", None) or not getattr(tool, "description", None):
                malformed.append(name)
            elif not callable(getattr(tool, "execute", None)):
                malformed.append(name)

        original_scene = context.window.scene
        tmp_scene = bpy.data.scenes.new("mcp_verify_tmp")
        context.window.scene = tmp_scene

        crashed = []
        validated = 0
        ran_clean = 0
        skipped = 0
        total = len(TOOL_REGISTRY)
        if context.window:
            context.window.cursor_modal_set("WAIT")
        try:
            for idx, (name, tool) in enumerate(TOOL_REGISTRY.items(), 1):
                if not self.include_heavy and any(k in name for k in _VERIFY_SKIP_KEYWORDS):
                    skipped += 1
                    continue
                # force_redraw=True: this loop runs entirely inside one
                # Operator.execute() call, so a plain tag_redraw() would never
                # actually paint until every tool is done -- see
                # push_hud_update's docstring.
                push_hud_update(
                    title="Verify Tools",
                    status=f"Testing '{name}' ({idx}/{total})...",
                    progress_percent=(idx - 1) / total * 100.0,
                    step_current=idx,
                    step_total=total,
                    force_redraw=True,
                )
                try:
                    result = tool.execute({})
                    if isinstance(result, dict) and result.get("success") is False:
                        validated += 1
                    else:
                        ran_clean += 1
                except Exception as exc:  # noqa: BLE001 -- collecting failures is the point
                    crashed.append((name, str(exc)))
        finally:
            context.window.scene = original_scene
            bpy.data.scenes.remove(tmp_scene)
            for _ in range(3):
                bpy.ops.outliner.orphans_purge(do_local_ids=True, do_linked_ids=True, do_recursive=True)
            if context.window:
                context.window.cursor_modal_restore()

        summary = (
            f"{total} tools: {validated} validated cleanly, {ran_clean} ran with no params, "
            f"{skipped} skipped (heavy), {len(crashed)} raised an exception"
        )
        if malformed:
            summary += f"; {len(malformed)} malformed registration(s)"

        push_hud_update(
            title="Verify Tools",
            status="Done",
            progress_percent=100.0,
            step_current=total,
            step_total=total,
            completed_summary=summary[:80],
            auto_hide_seconds=6.0,
            force_redraw=True,
        )

        if crashed or malformed:
            for name, err in crashed:
                print(f"[MCP Bridge] '{name}'.execute({{}}) raised: {err}")
            for name in malformed:
                print(f"[MCP Bridge] '{name}' is malformed in TOOL_REGISTRY")
            self.report({"WARNING"}, summary + " -- see System Console for details")
            return {"CANCELLED"}

        self.report({"INFO"}, summary)
        return {"FINISHED"}


_JOB_STATE_ICONS = {
    "QUEUED": ("Queued", "TIME"),
    "RUNNING": ("Running", "PLAY"),
    "COMPLETED": ("Done", "CHECKMARK"),
    "CANCELLED": ("Cancelled", "X"),
    "FAILED": ("Failed", "ERROR"),
}

_JOB_ACTIVE_STATES = ("QUEUED", "RUNNING")
_JOB_TERMINAL_STATES = ("COMPLETED", "CANCELLED", "FAILED")


def _fmt_job_duration(seconds) -> str:
    """Short human duration for task rows: '4.2s', '2m 05s', '1h 02m'."""
    if seconds is None:
        return "--"
    try:
        total = max(0.0, float(seconds))
    except (TypeError, ValueError):
        return "--"
    if total < 60.0:
        return f"{total:.1f}s"
    minutes = int(total // 60)
    if minutes < 60:
        return f"{minutes}m {int(total % 60):02d}s"
    return f"{minutes // 60}h {minutes % 60:02d}m"


def _recent_jobs(limit: int = 8) -> list:
    try:
        return TOOL_REGISTRY["list_jobs"].execute({"limit": limit}).get("jobs", [])
    except Exception:
        return []


def _active_job(jobs: list) -> dict | None:
    for job in jobs:
        if job.get("status") == "RUNNING":
            return job
    for job in jobs:
        if job.get("status") == "QUEUED":
            return job
    return None


def _get_job(job_id: str) -> dict | None:
    try:
        res = TOOL_REGISTRY["get_job_status"].execute({"job_id": job_id})
    except Exception:
        return None
    return res.get("job") if res.get("success") else None


def tick_tasks_redraw() -> float:
    """bpy.app.timers callback: while a background task is active, tag 3D
    views for redraw twice a second so the Background Tasks panel box (and
    its live progress lines) follows the running job without any clicks.
    Idle cost is one cheap job-list read per tick, no redraws scheduled."""
    try:
        jobs = TOOL_REGISTRY["list_jobs"].execute({"limit": 5}).get("jobs", [])
        if any(j.get("status") in _JOB_ACTIVE_STATES for j in jobs):
            wm = getattr(bpy.context, "window_manager", None)
            if wm is not None:
                for window in wm.windows:
                    for area in window.screen.areas:
                        if area.type == "VIEW_3D":
                            area.tag_redraw()
    except Exception:
        pass
    return 0.5


class MCP_OT_abort_job(bpy.types.Operator):
    bl_idname = "mcp_bridge.abort_job"
    bl_label = "Abort Task"
    bl_description = "Abort a running or queued background task -- remaining steps are dropped"
    bl_options = {"REGISTER"}

    job_id: bpy.props.StringProperty(name="Job ID")

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=380)

    def draw(self, context):
        layout = self.layout
        job = _get_job(self.job_id) or {}
        col = layout.column()
        col.alert = True
        col.label(text=f"Abort '{job.get('name', self.job_id)}'?", icon="ERROR")
        if job.get("message"):
            layout.label(text=str(job["message"])[:60], icon="INFO")

    def execute(self, context):
        result = TOOL_REGISTRY["cancel_job"].execute({"job_id": self.job_id})
        if not result.get("success"):
            self.report({"ERROR"}, result.get("message", "Abort failed"))
            return {"CANCELLED"}
        self.report({"INFO"}, result.get("message", f"Aborted '{self.job_id}'"))
        return {"FINISHED"}


class MCP_OT_delete_job(bpy.types.Operator):
    bl_idname = "mcp_bridge.delete_job"
    bl_label = "Delete Task"
    bl_description = "Forget one finished background task record"
    bl_options = {"REGISTER"}

    job_id: bpy.props.StringProperty(name="Job ID")

    def execute(self, context):
        result = TOOL_REGISTRY["delete_job"].execute({"job_id": self.job_id})
        if not result.get("success"):
            self.report({"ERROR"}, result.get("message", "Delete failed"))
            return {"CANCELLED"}
        self.report({"INFO"}, result["message"])
        return {"FINISHED"}


class MCP_OT_prune_old_jobs(bpy.types.Operator):
    bl_idname = "mcp_bridge.prune_old_jobs"
    bl_label = "Clean Tasks Older Than 1 Day"
    bl_description = "Forget finished background task records older than 1 day (running/queued tasks are never touched)"
    bl_options = {"REGISTER"}

    def execute(self, context):
        result = TOOL_REGISTRY["prune_jobs"].execute({"older_than_days": 1.0})
        if not result.get("success"):
            self.report({"ERROR"}, result.get("message", "Cleanup failed"))
            return {"CANCELLED"}
        self.report({"INFO"}, result["message"])
        return {"FINISHED"}


class MCP_OT_show_job_details(bpy.types.Operator):
    bl_idname = "mcp_bridge.show_job_details"
    bl_label = "Task Details"
    bl_description = "Show a task's full record: state, date/time, duration, progress, and every explanation line"
    bl_options = {"REGISTER"}

    job_id: bpy.props.StringProperty(name="Job ID")

    _job = None

    def invoke(self, context, event):
        job = _get_job(self.job_id)
        if not job:
            self.report({"ERROR"}, f"Task '{self.job_id}' not found")
            return {"CANCELLED"}
        MCP_OT_show_job_details._job = job
        return context.window_manager.invoke_props_dialog(self, width=520)

    def draw(self, context):
        layout = self.layout
        job = MCP_OT_show_job_details._job or {}
        state, icon = _JOB_STATE_ICONS.get(job.get("status"), (str(job.get("status")), "DOT"))
        layout.label(text=f"{job.get('name', '?')} -- {state}", icon=icon)
        layout.label(text=f"Started: {job.get('created', '--')}  |  Duration: {_fmt_job_duration(job.get('duration_seconds'))}", icon="TIME")
        layout.label(text=f"Progress: {job.get('progress', 0):.0f}%  |  ID: {job.get('id', '')}", icon="INFO")
        if job.get("message"):
            box = layout.box()
            box.label(text=str(job["message"])[:80], icon="WORDWRAP_ON")

        result = job.get("result") or {}
        if result.get("message"):
            box = layout.box()
            box.label(text="Result:", icon="CHECKMARK")
            for chunk in [str(result["message"])[i:i + 70] for i in range(0, len(str(result["message"])), 70)][:4]:
                box.label(text=chunk)
        history = (result.get("history") or {})
        steps = history.get("steps") or []
        if steps:
            box = layout.box()
            total_s = history.get("total_seconds", 0.0)
            box.label(text=f"Steps ({len(steps)}, {total_s:.1f}s total):", icon="LINENUMBERS_ON")
            col = box.column()
            col.scale_y = 0.9
            for step in steps[-14:]:
                col.label(text=f"{step.get('elapsed_s', 0):.1f}s [{step.get('progress_pct', 0):.0f}%] {str(step.get('status', ''))[:52]}")
        if (result.get("vision_renames") or []):
            layout.label(text=f"+{len(result['vision_renames'])} vision-assisted rename(s)", icon="OUTLINER_OB_MESH")
        if job.get("error"):
            box = layout.box()
            box.alert = True
            box.label(text=str(job["error"])[:80], icon="ERROR")

    def execute(self, context):
        return {"FINISHED"}


class MCP_OT_show_all_tasks(bpy.types.Operator):
    bl_idname = "mcp_bridge.show_all_tasks"
    bl_label = "Tasks History"
    bl_description = "Show every tracked background task -- date/time, duration, state, progress, and message -- newest first"
    bl_options = {"REGISTER"}

    _jobs = []

    def invoke(self, context, event):
        jobs = _recent_jobs(60)
        if not jobs:
            self.report({"INFO"}, "No background tasks tracked yet")
            return {"CANCELLED"}
        MCP_OT_show_all_tasks._jobs = jobs
        return context.window_manager.invoke_props_dialog(self, width=640)

    def draw(self, context):
        layout = self.layout
        # Fresh read on every redraw: delete/prune buttons below mutate the
        # records, and the next redraw (triggered by the click itself) then
        # shows the list without the removed rows -- no stale snapshot.
        jobs = _recent_jobs(60)
        MCP_OT_show_all_tasks._jobs = jobs
        layout.label(text=f"{len(jobs)} task(s), newest first:", icon="TIME")
        for job in jobs:
            state, icon = _JOB_STATE_ICONS.get(job.get("status"), (str(job.get("status")), "DOT"))
            box = layout.box()
            top = box.row()
            top.label(text=f"{job.get('created', '--')} -- {job.get('name', '?')}", icon=icon)
            top.label(text=state)
            if job.get("status") in _JOB_TERMINAL_STATES:
                op = top.operator(MCP_OT_delete_job.bl_idname, text="", icon="TRASH")
                op.job_id = job["id"]
            mid = box.row()
            mid.label(text=f"Duration: {_fmt_job_duration(job.get('duration_seconds'))}")
            mid.label(text=f"Progress: {job.get('progress', 0):.0f}%")
            if job.get("message"):
                box.label(text=str(job["message"])[:76], icon="WORDWRAP_ON")
            if job.get("error"):
                err = box.row()
                err.alert = True
                err.label(text=str(job["error"])[:76], icon="ERROR")
        layout.separator()
        layout.operator(MCP_OT_prune_old_jobs.bl_idname, icon="TRASH")

    def execute(self, context):
        return {"FINISHED"}


import bpy.utils.previews

from ..tools import TOOL_REGISTRY
from .preferences import status_text_and_icon

_preview_collections: dict = {}
_search_results_cache: list = []
# True when the last online search returned a full page (limit hits), i.e.
# there may be another page after this one. Set by run_online_search, read
# by the pagination row so Next is only enabled when it can go somewhere.
_search_has_more: bool = False
_SEARCH_PAGE_LIMIT = 15


def _get_search_items_callback(self, context):
    if not _search_results_cache:
        return [("NONE", "Click 'Search Online' to find models", "Enter query and click search", "INFO", 0)]
    return _search_results_cache
def run_online_search(self, context):
    global _search_results_cache, _search_has_more
    from ..bridge import dispatch

    query = self.search_query.strip()
    if not query:
        return

    dispatch.set_client_status(f"Searching online for '{query}' (page {self.search_page})...")

    try:
        bpy.ops.wm.redraw_timer(type='DRAW', iterations=1)
    except Exception:
        pass

    if context.window:
        context.window.cursor_modal_set("WAIT")
    try:
        if "main" not in _preview_collections:
            try:
                _preview_collections["main"] = bpy.utils.previews.new()
            except Exception:
                pass

        pcoll = _preview_collections.get("main")
        provider = self.search_provider

        from ..tools.super_import_ops import download_thumbnail, search_all_online_models

        limit = _SEARCH_PAGE_LIMIT
        offset = (self.search_page - 1) * limit
        try:
            since_year = int(getattr(self, "since_year", "0") or "0")
        except Exception:
            since_year = 0
        hits = search_all_online_models(
            query, provider=provider, limit=limit, offset=offset,
            sort_by=getattr(self, "sort_by", "RELEVANCE"),
            file_format=getattr(self, "file_format", "ANY"),
            license_filter=getattr(self, "license_filter", "ANY"),
            vert_band=getattr(self, "vert_band", "ANY"),
            since_year=since_year,
            author=getattr(self, "author", ""),
            min_faces=getattr(self, "min_faces", 0),
            max_faces=getattr(self, "max_faces", 0),
        )
        # A full page means there may be more behind it; a short/empty page
        # means this is the last one, so Next must disable.
        _search_has_more = bool(hits) and len(hits) >= limit
        if not hits:
            _search_results_cache = [
                ("NONE", f"No models found for '{query}'", "Try another keyword or change provider", "ERROR", 0)
            ]
        else:
            items = []
            for i, hit in enumerate(hits):
                raw_id = hit["id"]
                prov = hit.get("provider", "online").lower()
                full_key = f"{prov}:{raw_id}"
                icon_id = 0
                if pcoll is not None and hit.get("thumbnail_url"):
                    if raw_id not in pcoll:
                        thumb_path = download_thumbnail(raw_id, hit["thumbnail_url"])
                        if thumb_path:
                            try:
                                pcoll.load(raw_id, thumb_path, "IMAGE")
                            except Exception:
                                pass
                    if raw_id in pcoll:
                        icon_id = pcoll[raw_id].icon_id

                prov_tag = prov.upper()
                poly_str = f"{hit['polycount']:,} verts" if hit.get("polycount") else "PBR asset"
                label = f"[{prov_tag}] {hit['name']} ({poly_str})"
                desc_parts = []
                if getattr(self, "sort_by", "RELEVANCE") == "LICENSE":
                    desc_parts.append(f"[{hit.get('license', '?')}]")
                desc_parts += [f"{hit['credits']}", f"{hit.get('downloads', 0):,} downloads"]
                if hit.get("rating"):
                    desc_parts.append(f"{hit['rating']:,} likes")
                if hit.get("views"):
                    desc_parts.append(f"{hit['views']:,} views")
                if hit.get("date_published"):
                    try:
                        import datetime as _dt
                        year = _dt.datetime.fromtimestamp(hit["date_published"]).year
                        desc_parts.append(str(year))
                    except Exception:
                        pass
                if hit.get("dim_max"):
                    desc_parts.append(f"max-dim {hit['dim_max']:.0f}")
                desc = " | ".join(desc_parts)
                items.append((full_key, label, desc, icon_id or "OBJECT_DATA", i))
            _search_results_cache = items

        default_asset = "NONE"
        if _search_results_cache and _search_results_cache[0][0] != "NONE":
            default_asset = _search_results_cache[0][0]

        self.selected_asset = default_asset

    finally:
        dispatch.set_client_status(None)
        if context.window:
            context.window.cursor_modal_restore()


def _page_prev_callback(self, context):
    if not self.page_prev:
        return
    self.page_prev = False
    if self.search_page > 1:
        self.search_page -= 1
        run_online_search(self, context)


def _page_next_callback(self, context):
    if not self.page_next:
        return
    self.page_next = False
    if not _search_has_more:
        return
    self.search_page += 1
    run_online_search(self, context)


def _search_scope_changed(self, context):
    """New query/provider invalidates pagination: back to page 1 with no
    known next page until a fresh search runs."""
    global _search_has_more
    self.search_page = 1
    _search_has_more = False


def _open_url_callback(self, context):
    if not self.open_url:
        return
    self.open_url = False

    selected = self.selected_asset
    if not selected or selected == "NONE":
        return

    if ":" in selected:
        provider, asset_id = selected.split(":", 1)
    else:
        provider = self.search_provider
        asset_id = selected

    import webbrowser
    url = ""
    prov_lower = provider.lower()
    if "polyhaven" in prov_lower:
        url = f"https://polyhaven.com/a/{asset_id}"
    elif "sketchfab" in prov_lower:
        url = f"https://sketchfab.com/3d-models/{asset_id}"
    elif "ambientcg" in prov_lower:
        url = f"https://ambientcg.com/view?id={asset_id}"

    if url:
        webbrowser.open(url)


def _run_search_callback(self, context):
    if not self.trigger_search:
        return
    self.trigger_search = False
    run_online_search(self, context)





class MCP_OT_show_env_info(bpy.types.Operator):
    bl_idname = "mcp_bridge.show_env_info"
    bl_label = ".env"
    bl_description = (
        "Show which .env files this Blender process loaded (with their full paths) and which "
        "API keys/secrets are configured, masked as first3...last3 characters"
    )
    bl_options = {"REGISTER"}

    _info = None

    def invoke(self, context, event):
        MCP_OT_show_env_info._info = TOOL_REGISTRY["get_env_info"].execute({})
        return context.window_manager.invoke_props_dialog(self, width=640)

    def draw(self, context):
        import os

        layout = self.layout
        info = MCP_OT_show_env_info._info or {}

        if not info.get("success"):
            layout.label(text=info.get("message", "Failed to read environment info"), icon="ERROR")
            return

        # Precedence is "first candidate that declares the key wins" (see
        # config.env_file_candidates), so number the files in that order and
        # reuse the same number in the Keys table below -- a per-row full
        # absolute path gets clipped in a narrow column and doesn't convey
        # precedence anyway; "[N]" pointing back at this ordered list does.
        box_files = layout.box()
        box_files.label(text=".env Files (search order, first match per key wins)", icon="FILE_TEXT")
        path_to_index: dict[str, int] = {}
        for i, f in enumerate(info.get("env_files", []), start=1):
            path_to_index[f["path"]] = i
            row = box_files.row()
            row.label(text=f"{i}.", icon="CHECKMARK" if f.get("exists") else "X")
            row.label(text=f["path"])
            row.label(text="found" if f.get("exists") else "not found")

        layout.separator()
        box_keys = layout.box()
        box_keys.label(text="Keys", icon="LOCKED")
        keys = info.get("keys", {})
        if not keys:
            box_keys.label(text="No keys found", icon="INFO")
        else:
            header = box_keys.split(factor=0.35)
            header.label(text="Key")
            sub = header.split(factor=0.4)
            sub.label(text="Value")
            sub.label(text="Source")
            for name, data in keys.items():
                source = data.get("source") or ""
                if source == "environment":
                    source_text = "environment (real env var, wins over .env)"
                elif source in path_to_index:
                    # e.g. "[2] .mcp-blender\.env" -- short enough to stay
                    # readable in-row, full path is row 2 in the box above.
                    source_text = f"[{path_to_index[source]}] {os.path.basename(source)}"
                else:
                    source_text = source
                row = box_keys.split(factor=0.35)
                row.label(text=name)
                sub = row.split(factor=0.4)
                sub.label(text=data.get("masked", ""))
                sub.label(text=source_text)

        layout.separator()
        layout.label(
            text="Tip: set keys in Edit > Preferences > Add-ons > MCP Bridge > API Keys.",
            icon="INFO",
        )
        py = info.get("python", {})
        layout.label(
            text=f"venv: {py.get('venv_path', '')} (in_venv={py.get('in_venv')}, python {py.get('version', '')})",
            icon="SCRIPTPLUGINS",
        )

    def execute(self, context):
        return {"FINISHED"}


class MCP_OT_super_import(bpy.types.Operator):
    bl_idname = "mcp_bridge.super_import"
    bl_label = "Super Import..."
    bl_description = (
        "Search online models across Poly Haven, Sketchfab, and ambientCG with previews, "
        "vertex counts, and credits, or import local files with automatic mesh simplification"
    )
    bl_options = {"REGISTER", "UNDO"}

    source_type: bpy.props.EnumProperty(
        name="Source",
        description="Asset acquisition source",
        items=[
            ("SEARCH", "Search Online (Poly Haven, Sketchfab, ambientCG)", "Search online 3D models with previews and polycount ranking", "VIEWZOOM", 0),
            ("FILE", "Local File", "Pick a 3D model file (.glb, .gltf, .fbx, .obj, .stl, .usd, .zip) from disk", "FILE_FOLDER", 1),
            ("URL", "Direct URL / AI Model", "Direct download from HTTP/HTTPS link (Meshy, Tripo, Trellis, GLB link)", "SHADERFX", 2),
        ],
        default="SEARCH",
    )

    search_provider: bpy.props.EnumProperty(
        name="Provider",
        description="Online library provider to search",
        items=[
            ("ALL", "All Providers (Poly Haven, Sketchfab, ambientCG)", "Search across all supported online libraries", "WORLD", 0),
            ("POLYHAVEN", "Poly Haven (CC0 3D Models)", "Search Poly Haven CC0 library", "IMAGE", 1),
            ("SKETCHFAB", "Sketchfab (Models Catalog)", "Search Sketchfab downloadable models", "COMMUNITY", 2),
            ("AMBIENTCG", "ambientCG (CC0 PBR Assets)", "Search ambientCG materials & models", "FILE_IMAGE", 3),
        ],
        default="ALL",
        update=_search_scope_changed,
    )

    search_query: bpy.props.StringProperty(
        name="Search Query",
        description="Keyword to search online models (e.g. chair, table, car, plant, bottle, sword)",
        default="chair",
        update=_search_scope_changed,
    )

    sort_by: bpy.props.EnumProperty(
        name="Sort By",
        description="Result order: relevance, popularity (downloads), date (newest), rating (likes, mostly Sketchfab), vertex count, physical dimensions (Poly Haven models), or licence openness (CC0 first)",
        items=[
            ("RELEVANCE", "Relevance", "Provider relevance ranking, merged by popularity", "SORTALPHA", 0),
            ("POPULARITY", "Popularity", "Most downloaded first", "FUND", 1),
            ("DATE", "Date (newest)", "Most recently published first", "TIME", 2),
            ("RATING", "Rating (likes)", "Most liked first (Sketchfab likes; other providers carry no rating)", "SOLO_ON", 3),
            ("VERTICES_DESC", "Vertices (high first)", "Highest vertex count first", "TRIA_DOWN", 4),
            ("VERTICES_ASC", "Vertices (low first)", "Lowest vertex count first -- lightest assets", "TRIA_UP", 5),
            ("DIMENSIONS", "Dimensions (largest)", "Largest physical size first (Poly Haven models)", "FULLSCREEN_ENTER", 6),
            ("LICENSE", "Licence (open first)", "CC0 first, then CC-BY, then other OSS licences, restrictive last", "LOCKED", 7),
        ],
        default="RELEVANCE",
        update=_search_scope_changed,
    )

    file_format: bpy.props.EnumProperty(
        name="Format",
        description="Keep only assets advertising this format: Poly Haven glTF plus Sketchfab glb archives and uploader format tags (best-effort for FBX/OBJ)",
        items=[
            ("ANY", "Any format", "No format filtering", "FILE", 0),
            ("GLB", "GLB / glTF", "Assets with a glTF download (Poly Haven models, Sketchfab glb archives)", "MESH_DATA", 1),
            ("FBX", "FBX", "Assets tagged FBX by the uploader (Sketchfab; best-effort)", "OBJECT_DATA", 2),
            ("OBJ", "OBJ", "Assets tagged OBJ by the uploader (Sketchfab; best-effort)", "META_CUBE", 3),
        ],
        default="ANY",
        update=_search_scope_changed,
    )

    license_filter: bpy.props.EnumProperty(
        name="Licence",
        description="Keep only licences at least this open: CC0 only, CC-BY-compatible, or any open-source licence",
        items=[
            ("ANY", "Any licence", "No licence filtering", "WORLD", 0),
            ("CC0", "CC0 only", "Public domain, no attribution required", "LOCKED", 1),
            ("CC_BY", "CC-BY compatible", "CC0 plus CC-BY family (attribution required)", "KEYFRAME", 2),
            ("OSS", "Open licences", "CC0, CC-BY family and other OSS licences (MIT/Apache/GPL); excludes editorial/standard", "COMMUNITY", 3),
        ],
        default="ANY",
        update=_search_scope_changed,
    )

    vert_band: bpy.props.EnumProperty(
        name="Vertices",
        description="Keep only assets in this vertex-count band (hits with unknown counts are excluded while set)",
        items=[
            ("ANY", "Any size", "No vertex-count filtering", "WORLD", 0),
            ("LIGHT", "< 10k", "Light props, quick to simplify", "LIGHT", 1),
            ("MEDIUM", "10k - 50k", "Hero-prop range around the 50k pipeline default", "DOT", 2),
            ("DENSE", "50k - 200k", "Dense scans and detailed models", "MESH_CUBE", 3),
            ("HEAVY", "> 200k", "Heavy AI generations and raw scans", "TRIA_DOWN", 4),
        ],
        default="ANY",
        update=_search_scope_changed,
    )

    since_year: bpy.props.EnumProperty(
        name="Since",
        description="Keep only assets published in or after this year (hits with unknown dates are excluded while set)",
        items=[
            ("0", "Any time", "No recency filtering", "WORLD", 0),
            ("2025", "2025+", "Published in 2025 or later", "TIME", 1),
            ("2024", "2024+", "Published in 2024 or later", "TIME", 2),
            ("2023", "2023+", "Published in 2023 or later", "TIME", 3),
            ("2022", "2022+", "Published in 2022 or later", "TIME", 4),
            ("2020", "2020+", "Published in 2020 or later", "TIME", 5),
        ],
        default="0",
        update=_search_scope_changed,
    )

    author: bpy.props.StringProperty(
        name="Author",
        description="Keep only assets whose creator name contains this text (ambientCG reports no author and is excluded while set)",
        default="",
        update=_search_scope_changed,
    )

    min_faces: bpy.props.IntProperty(
        name="Min Faces",
        description="Keep only assets with at least this many faces (0 = no minimum; exact server-side on Sketchfab, Poly Haven polycount doubles as the proxy; unknown counts excluded while set)",
        default=0,
        min=0,
        update=_search_scope_changed,
    )

    max_faces: bpy.props.IntProperty(
        name="Max Faces",
        description="Keep only assets with at most this many faces (0 = no maximum; exact server-side on Sketchfab, Poly Haven polycount doubles as the proxy; unknown counts excluded while set)",
        default=0,
        min=0,
        update=_search_scope_changed,
    )

    trigger_search: bpy.props.BoolProperty(
        name="Search Online",
        description="Click to search online libraries",
        default=False,
        update=_run_search_callback,
    )

    search_page: bpy.props.IntProperty(
        name="Page",
        description="Current search result page",
        default=1,
        min=1,
    )

    page_prev: bpy.props.BoolProperty(
        name="Previous Page",
        description="Go to previous page of search results",
        default=False,
        update=_page_prev_callback,
    )

    page_next: bpy.props.BoolProperty(
        name="Next Page",
        description="Go to next page of search results",
        default=False,
        update=_page_next_callback,
    )

    open_url: bpy.props.BoolProperty(
        name="View Online",
        description="Open the model page in your web browser",
        default=False,
        update=_open_url_callback,
    )

    selected_asset: bpy.props.EnumProperty(
        name="Matching Models",
        description="Select a model ordered by importance and popularity",
        items=_get_search_items_callback,
    )

    filepath: bpy.props.StringProperty(
        name="File Path",
        description="Path to local 3D file or archive",
        subtype="FILE_PATH",
        default="",
    )

    direct_url: bpy.props.StringProperty(
        name="Direct URL",
        description="HTTP/HTTPS download link to .glb / .gltf / .zip",
        default="",
    )

    simplifier_tool: bpy.props.EnumProperty(
        name="Simplifier",
        description="Mesh reduction method applied after import",
        items=[
            ("SIMPLIFY", "Simplify Geometry (Preserve Form)", "Form-preserving repair, curvature decimation & rollback quality gate", "MOD_DECIM", 0),
            ("DECIMATE", "Decimate (Ratio/Collapse)", "Standard ratio decimation modifier", "MOD_SIMPLIFY", 1),
            ("REMESH", "Voxel Remesh", "Uniform voxel reconstruction (destroys UVs)", "MOD_REMESH", 2),
            ("NONE", "None (Keep Original)", "Do not reduce mesh geometry", "RESTRICT_RENDER_OFF", 3),
        ],
        default="SIMPLIFY",
    )

    target_vertices: bpy.props.IntProperty(
        name="Target Vertices",
        description="Target vertex count budget per mesh object",
        default=50000,
        min=10,
        max=10000000,
    )

    auto_orient: bpy.props.BoolProperty(
        name="Auto Orient",
        description="Automatically detect and correct upside-down or lying-down models",
        default=True,
    )

    normalize_scale: bpy.props.BoolProperty(
        name="Normalize Size & Ground",
        description="Auto-rescale model to real-world target dimension (e.g. 2.0m) and align base to ground Z=0",
        default=True,
    )

    target_size: bpy.props.FloatProperty(
        name="Target Size (m)",
        description="Target maximum dimension in meters (e.g. 1.0m chair, 2.0m vehicle/person, 0.5m prop)",
        default=2.0,
        min=0.01,
        max=1000.0,
    )

    ground_to_floor: bpy.props.BoolProperty(
        name="Ground at Z=0",
        description="Align the bottom base of the model flush on the ground plane (Z=0)",
        default=True,
    )

    center_xy: bpy.props.BoolProperty(
        name="Center at (0, 0)",
        description="Center model horizontally at origin",
        default=True,
    )

    collection_name: bpy.props.StringProperty(
        name="Collection",
        description="Target collection name (leave blank for active scene collection)",
        default="",
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=480)

    def draw(self, context):
        layout = self.layout
        layout.prop(self, "source_type", expand=True)

        if self.source_type == "SEARCH":
            box_search = layout.box()
            box_search.label(text="Search Online 3D Libraries", icon="WORLD")
            box_search.prop(self, "search_provider")
            
            row = box_search.row(align=True)
            row.prop(self, "search_query", text="Keyword", icon="VIEWZOOM")
            row.prop(self, "trigger_search", text="Search Online", icon="VIEWZOOM", toggle=True)

            box_search.prop(self, "sort_by", text="Sort")

            box_filt = box_search.box()
            box_filt.label(text="Filters", icon="FILTER")
            row_f1 = box_filt.row(align=True)
            row_f1.prop(self, "file_format")
            row_f1.prop(self, "license_filter")
            row_f2 = box_filt.row(align=True)
            row_f2.prop(self, "vert_band")
            row_f2.prop(self, "since_year")
            row_f3 = box_filt.row(align=True)
            row_f3.prop(self, "min_faces")
            row_f3.prop(self, "max_faces")
            box_filt.prop(self, "author", icon="USER")

            # Pagination row -- each button lives in its own sub-row so it
            # can be greyed out independently when it cannot go anywhere.
            row_page = box_search.row(align=True)
            sub_prev = row_page.row(align=True)
            sub_prev.enabled = self.search_page > 1
            sub_prev.prop(self, "page_prev", text="Previous Page", icon="TRIA_LEFT", toggle=True)
            row_page.label(text=f"Page {self.search_page}", icon="FILE_TICK")
            sub_next = row_page.row(align=True)
            sub_next.enabled = _search_has_more
            sub_next.prop(self, "page_next", text="Next Page", icon="TRIA_RIGHT", toggle=True)

            box_search.separator()
            box_search.label(text="Found Models:", icon="SORT_DESC")
            box_search.template_icon_view(self, "selected_asset", show_labels=True)
            
            row_sel = box_search.row(align=True)
            row_sel.prop(self, "selected_asset", text="")
            if self.selected_asset and self.selected_asset != "NONE":
                row_sel.prop(self, "open_url", text="View Online (3D / Full)", icon="WORLD", toggle=True)

        elif self.source_type == "FILE":
            box_file = layout.box()
            box_file.label(text="Local 3D File", icon="FILE_FOLDER")
            box_file.prop(self, "filepath")
            box_file.label(text="Supports: .glb, .gltf, .fbx, .obj, .stl, .usd, .blend, .zip", icon="INFO")

        elif self.source_type == "URL":
            box_url = layout.box()
            box_url.label(text="Direct Model URL", icon="SHADERFX")
            box_url.prop(self, "direct_url")
            box_url.label(text="Supports direct link to .glb, .gltf, or AI model outputs", icon="INFO")

        layout.separator()
        box_norm = layout.box()
        box_norm.label(text="Real-World Size & Grounding", icon="ORIENTATION_GIMBAL")
        box_norm.prop(self, "normalize_scale")
        if self.normalize_scale:
            row_s = box_norm.row()
            row_s.prop(self, "target_size")
            row_g = box_norm.row()
            row_g.prop(self, "ground_to_floor")
            row_g.prop(self, "center_xy")

        layout.separator()
        box_sim = layout.box()
        box_sim.label(text="Mesh Reduction & Vertex Budget", icon="MOD_DECIM")
        box_sim.prop(self, "simplifier_tool")
        if self.simplifier_tool != "NONE":
            box_sim.prop(self, "target_vertices")

        layout.separator()
        box_opt = layout.box()
        box_opt.label(text="Placement Options", icon="TOOL_SETTINGS")
        box_opt.prop(self, "auto_orient")
        box_opt.prop(self, "collection_name")

    def execute(self, context):
        if self.source_type == "SEARCH":
            if not self.selected_asset or self.selected_asset == "NONE":
                self.report({"ERROR"}, "No valid model selected from search results")
                return {"CANCELLED"}
            selected = self.selected_asset
            if ":" in selected:
                provider, asset_id = selected.split(":", 1)
            else:
                provider = self.search_provider
                asset_id = selected
            filepath = ""
            url = ""
        elif self.source_type == "FILE":
            if not self.filepath:
                self.report({"ERROR"}, "Please choose a file to import")
                return {"CANCELLED"}
            asset_id = ""
            filepath = self.filepath
            url = ""
            provider = "FILE"
        else:  # URL
            if not self.direct_url:
                self.report({"ERROR"}, "Please enter a model URL")
                return {"CANCELLED"}
            asset_id = ""
            filepath = ""
            url = self.direct_url
            provider = "URL"

        params = {
            "source_type": self.source_type,
            "provider": provider,
            "asset_id": asset_id,
            "filepath": filepath,
            "url": url,
            "simplifier_tool": self.simplifier_tool,
            "target_vertices": self.target_vertices,
            "auto_orient": self.auto_orient,
            "normalize_scale": self.normalize_scale,
            "target_size": self.target_size,
            "ground_to_floor": self.ground_to_floor,
            "center_xy": self.center_xy,
            "collection_name": self.collection_name,
        }

        if context.window:
            context.window.cursor_modal_set("WAIT")
        try:
            result = TOOL_REGISTRY["super_import"].execute(params)
            if not result.get("success"):
                self.report({"ERROR"}, result.get("message", "Super import failed"))
                return {"CANCELLED"}

            self.report({"INFO"}, result["message"])
            return {"FINISHED"}
        finally:
            if context.window:
                context.window.cursor_modal_restore()


class MCP_OT_normalize_model(bpy.types.Operator):
    bl_idname = "mcp_bridge.normalize_model"
    bl_label = "Normalize Scale & Ground..."
    bl_description = "Rescale selected objects to real-world dimensions (e.g. 2.0m) and place base flush on ground Z=0"
    bl_options = {"REGISTER", "UNDO"}

    target_size: bpy.props.FloatProperty(
        name="Target Size (m)",
        description="Target maximum dimension in meters",
        default=2.0,
        min=0.01,
        max=1000.0,
    )

    ground: bpy.props.BoolProperty(
        name="Place on Ground (Z=0)",
        description="Align bottom base of model flush on ground grid",
        default=True,
    )

    center_xy: bpy.props.BoolProperty(
        name="Center at Origin",
        description="Center model horizontally at (0, 0)",
        default=True,
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=340)

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="Normalize Scale & Grounding", icon="ORIENTATION_GIMBAL")
        box.prop(self, "target_size")
        box.prop(self, "ground")
        box.prop(self, "center_xy")

        count = len(context.selected_objects)
        if count > 0:
            box.label(text=f"Selected: {count} object(s)", icon="OBJECT_DATA")
        else:
            box.label(text="All scene objects will be normalized", icon="INFO")

    def execute(self, context):
        selected = [obj.name for obj in context.selected_objects]
        params = {
            "target_size": self.target_size,
            "ground": self.ground,
            "center_xy": self.center_xy,
            "objects": selected if selected else None,
        }
        if context.window:
            context.window.cursor_modal_set("WAIT")
        try:
            result = TOOL_REGISTRY["normalize_model"].execute(params)
            if not result.get("success"):
                self.report({"ERROR"}, result.get("message", "Normalization failed"))
                return {"CANCELLED"}

            self.report({"INFO"}, result["message"])
            return {"FINISHED"}
        finally:
            if context.window:
                context.window.cursor_modal_restore()


class MCP_OT_simplify_mesh(bpy.types.Operator):
    bl_idname = "mcp_bridge.simplify_mesh"
    bl_label = "Simplify Mesh..."
    bl_description = "Reduce vertex budget using decimate, voxel remesh, or form-preserving simplify geometry"
    bl_options = {"REGISTER", "UNDO"}

    simplifier_tool: bpy.props.EnumProperty(
        name="Typology",
        description="Simplification method to apply",
        items=[
            ("SIMPLIFY", "Simplify Geometry (Preserve Form)", "Form-preserving repair, curvature decimation & rollback quality gate", "MOD_DECIM", 0),
            ("DECIMATE", "Decimate (Ratio/Collapse)", "Standard ratio decimation modifier", "MOD_SIMPLIFY", 1),
            ("REMESH", "Voxel Remesh", "Uniform voxel reconstruction (destroys UVs)", "MOD_REMESH", 2),
        ],
        default="SIMPLIFY",
    )

    target_vertices: bpy.props.IntProperty(
        name="Target Vertices",
        description="Target vertex count budget per mesh object",
        default=50000,
        min=10,
        max=10000000,
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=380)

    def draw(self, context):
        layout = self.layout
        # Original vertex counts first -- the user needs these before
        # choosing a target budget, so this box comes before the chooser.
        box_src = layout.box()
        box_src.label(text="Original Meshes & Vertex Counts", icon="OBJECT_DATA")
        mesh_objs = [obj for obj in context.selected_objects if obj.type == "MESH"]
        if not mesh_objs and context.active_object and context.active_object.type == "MESH":
            mesh_objs = [context.active_object]

        if mesh_objs:
            count = len(mesh_objs)
            total_verts = sum(len(o.data.vertices) for o in mesh_objs)
            for o in mesh_objs[:6]:
                try:
                    box_src.label(text=f"'{o.name}': {len(o.data.vertices):,} verts", icon="DOT")
                except Exception:
                    pass
            if count > 6:
                box_src.label(text=f"... (+{count - 6} more)", icon="INFO")
            box_src.label(text=f"Total original: {total_verts:,} verts in {count} mesh(es)", icon="INFO")
        else:
            box_src.label(text="No meshes selected! (Select in 3D View)", icon="ERROR")

        box = layout.box()
        box.label(text="Mesh Reduction & Vertex Budget", icon="MOD_DECIM")
        box.prop(self, "simplifier_tool")
        box.prop(self, "target_vertices")

        # Previous run card -- what the last simplify did, before choosing
        # the next budget. Cheap dict read; nothing to redraw-track.
        try:
            from ..tools.simplify_geometry_ops import get_last_card

            prev = get_last_card()
        except Exception:
            prev = None
        box_prev = layout.box()
        box_prev.label(text="Previous Simplify", icon="TIME")
        if not prev:
            box_prev.label(text="No simplify run yet this session.", icon="INFO")
        else:
            orig, res = prev.get("original_vertices"), prev.get("result_vertices")
            if orig is not None and res is not None:
                box_prev.label(text=f"'{prev.get('object_name')}': {orig:,} -> {res:,} verts", icon="DOT")
            else:
                box_prev.label(text=f"'{prev.get('object_name')}'", icon="DOT")
            box_prev.label(text=f"{prev.get('total_seconds', 0.0):.1f}s -- {prev.get('message', '')}"[:80], icon="INFO")
            if prev.get("rolled_back") and prev.get("suggested_retry_target"):
                box_prev.label(text=f"Rolled back; retry with target={prev['suggested_retry_target']}", icon="ERROR")

    def execute(self, context):
        import math

        from ..tools.progress_hud_ops import push_hud_update

        mesh_objs = [obj for obj in context.selected_objects if obj.type == "MESH"]
        if not mesh_objs and context.active_object and context.active_object.type == "MESH":
            mesh_objs = [context.active_object]

        if not mesh_objs:
            self.report({"WARNING"}, "No mesh objects selected in viewport")
            return {"CANCELLED"}

        if context.window:
            context.window.cursor_modal_set("WAIT")
        try:
            simplification_log = []
            budget = self.target_vertices
            success_count = 0
            total_objs = len(mesh_objs)

            for idx, obj in enumerate(mesh_objs, 1):
                current_verts = len(obj.data.vertices)
                if current_verts <= budget:
                    simplification_log.append(f"'{obj.name}' already under budget ({current_verts} verts)")
                    success_count += 1
                    continue

                # force_redraw=True: this loop runs entirely inside one
                # Operator.execute() call, so a plain tag_redraw() would never
                # actually paint until simplification of every selected mesh is
                # done -- see push_hud_update's docstring.
                push_hud_update(
                    title="Simplify Mesh",
                    status=f"{self.simplifier_tool.title()} '{obj.name}' ({idx}/{total_objs})...",
                    progress_percent=(idx - 1) / total_objs * 100.0,
                    step_current=idx,
                    step_total=total_objs,
                    force_redraw=True,
                    cursor_badge=True,
                    badge_text=f"Mesh {idx} of {total_objs} - starting '{obj.name}'",
                )

                if self.simplifier_tool == "SIMPLIFY":
                    simplify_tool = TOOL_REGISTRY.get("simplify_geometry")
                    if simplify_tool:
                        res = simplify_tool.execute({
                            "object_name": obj.name,
                            "target": budget,
                            "target_unit": "VERTICES",
                        })
                        if res.get("success"):
                            simplification_log.append(
                                f"Simplified '{obj.name}' ({current_verts} -> {res.get('result_vertices')} verts)"
                            )
                            success_count += 1
                        else:
                            # Fallback to decimate, matching super import logic
                            decimate_tool = TOOL_REGISTRY.get("decimate_mesh")
                            ratio = max(0.01, min(1.0, budget / current_verts))
                            if decimate_tool:
                                dec_res = decimate_tool.execute({"object_name": obj.name, "ratio": ratio})
                                if dec_res.get("success"):
                                    simplification_log.append(
                                        f"Decimated '{obj.name}' (ratio {ratio:.2f}) due to gate rollback"
                                    )
                                    success_count += 1
                                else:
                                    simplification_log.append(f"Failed to simplify '{obj.name}'")
                            else:
                                simplification_log.append(f"Failed to simplify '{obj.name}'")

                elif self.simplifier_tool == "DECIMATE":
                    decimate_tool = TOOL_REGISTRY.get("decimate_mesh")
                    if decimate_tool:
                        ratio = max(0.01, min(1.0, budget / current_verts))
                        res = decimate_tool.execute({"object_name": obj.name, "ratio": ratio})
                        if res.get("success"):
                            simplification_log.append(
                                f"Decimated '{obj.name}' ({current_verts} -> {res.get('result_vertices')} verts, ratio {ratio:.2f})"
                            )
                            success_count += 1
                        else:
                            simplification_log.append(f"Failed to decimate '{obj.name}'")

                elif self.simplifier_tool == "REMESH":
                    remesh_tool = TOOL_REGISTRY.get("remesh_mesh")
                    if remesh_tool:
                        max_dim = max(obj.dimensions) if any(obj.dimensions) else 1.0
                        N = max(10.0, min(200.0, math.sqrt(budget / 2.78)))
                        voxel_size = max(0.001, max_dim / N)
                        res = remesh_tool.execute({
                            "object_name": obj.name,
                            "mode": "VOXEL",
                            "voxel_size": voxel_size,
                        })
                        if res.get("success"):
                            simplification_log.append(
                                f"Remeshed '{obj.name}' ({current_verts} -> {res.get('result_vertices')} verts, voxel {voxel_size:.4f})"
                            )
                            success_count += 1
                        else:
                            simplification_log.append(f"Failed to remesh '{obj.name}'")

            summary = "; ".join(simplification_log)
            if success_count > 0:
                push_hud_update(
                    title="Simplify Mesh",
                    status=f"Done: {success_count}/{total_objs} mesh(es) simplified",
                    progress_percent=100.0,
                    step_current=total_objs,
                    step_total=total_objs,
                    completed_summary=summary[:80],
                    auto_hide_seconds=6.0,
                    force_redraw=True,
                )
                self.report({"INFO"}, f"Simplification done: {summary}")
                return {"FINISHED"}
            else:
                self.report({"ERROR"}, f"Simplification failed: {summary}")
                return {"CANCELLED"}
        finally:
            if context.window:
                context.window.cursor_modal_restore()


import os
import tempfile
from pathlib import Path

_CHECKPOINT_DIR = Path(tempfile.gettempdir()) / "mcp_blender_checkpoints"


def _list_checkpoint_names() -> list[str]:
    if not _CHECKPOINT_DIR.is_dir():
        return []
    return sorted(
        [p.stem for p in _CHECKPOINT_DIR.glob("*.blend")],
        key=lambda n: (_CHECKPOINT_DIR / f"{n}.blend").stat().st_mtime,
        reverse=True,
    )


class MCP_OT_restore_checkpoint(bpy.types.Operator):
    bl_idname = "mcp_bridge.restore_checkpoint"
    bl_label = "Restore Scene Checkpoint..."
    bl_description = "Restore the scene to a previously saved checkpoint snapshot"
    bl_options = {"REGISTER", "UNDO"}

    checkpoint: bpy.props.EnumProperty(
        name="Checkpoint",
        description="Select a checkpoint to restore",
        items=lambda self, ctx: [
            (n, n, f"Restore checkpoint '{n}'") for n in _list_checkpoint_names()
        ] or [("NONE", "No checkpoints found", "Create one first with 'Create Scene Checkpoint'")],
    )

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=420)

    def draw(self, context):
        layout = self.layout
        box = layout.box()
        box.label(text="Restore Scene Checkpoint", icon="FILE_TICK")
        box.prop(self, "checkpoint")
        if self.checkpoint == "NONE":
            box.label(text="No checkpoints available. Create one first.", icon="INFO")

    def execute(self, context):
        if self.checkpoint == "NONE":
            self.report({"WARNING"}, "No checkpoint selected")
            return {"CANCELLED"}

        from ..tools import TOOL_REGISTRY

        if context.window:
            context.window.cursor_modal_set("WAIT")
        try:
            result = TOOL_REGISTRY["restore_scene_checkpoint"].execute({"name": self.checkpoint})
            if not result.get("success"):
                self.report({"ERROR"}, result.get("message", "Restore failed"))
                return {"CANCELLED"}
            self.report({"INFO"}, result["message"])
            return {"FINISHED"}
        finally:
            if context.window:
                context.window.cursor_modal_restore()


class MCP_OT_ai_generate(bpy.types.Operator):
    bl_idname = "mcp_bridge.ai_generate"
    bl_label = "AI Generate 3D Model..."
    bl_description = "Generate a 3D model from a text prompt or an image (image-to-3D) using Meshy AI or Tripo3D"
    bl_options = {"REGISTER", "UNDO"}

    provider: bpy.props.EnumProperty(
        name="Provider",
        description="AI 3D generation provider",
        items=[
            ("meshy", "Meshy AI", "Meshy AI text-to-3D and image-to-3D generation", "SHADERFX", 0),
            ("tripo", "Tripo3D", "Tripo3D text-to-3D and image-to-3D generation", "VIEW3D", 1),
        ],
        default="meshy",
    )

    source_mode: bpy.props.EnumProperty(
        name="Input",
        description="What to generate the model from",
        items=[
            ("TEXT", "Text Prompt", "Describe the model in words (text-to-3D)", "FONT_DATA", 0),
            ("IMAGE", "Image", "Generate from a picture on disk (image-to-3D) -- use Paste to grab it from the clipboard", "IMAGE_DATA", 1),
        ],
        default="TEXT",
    )

    prompt: bpy.props.StringProperty(
        name="Prompt",
        description="Text description of the 3D model to generate (e.g. 'a medieval sword', 'a wooden chair')",
        default="",
    )

    image_path: bpy.props.StringProperty(
        name="Image",
        description="Path to a .png/.jpg/.jpeg/.webp picture to generate the model from",
        subtype="FILE_PATH",
        default="",
    )

    reduction_method: bpy.props.EnumProperty(
        name="Reduction Method",
        description="Mesh reduction applied after generation",
        items=[
            ("simplify", "Simplify (Preserve Form)", "Form-preserving repair & curvature decimation", "MOD_DECIM", 0),
            ("decimate", "Decimate (Ratio)", "Standard ratio decimation", "MOD_SIMPLIFY", 1),
            ("remesh", "Voxel Remesh", "Uniform voxel reconstruction (destroys UVs)", "MOD_REMESH", 2),
            ("none", "None (Keep Original)", "Do not reduce generated mesh", "RESTRICT_RENDER_OFF", 3),
        ],
        default="simplify",
    )

    target_vertices: bpy.props.IntProperty(
        name="Target Vertices",
        description="Target vertex count budget for the generated model",
        default=50000,
        min=100,
        max=100000,
        step=1000,
    )

    collection_name: bpy.props.StringProperty(
        name="Collection",
        description="Target collection (e.g. 'Generated/Meshy')",
        default="",
    )

    _thread = None
    _job = None
    _timer = None
    _area = None
    # Cached preview of the currently referenced image file. Class-level so it
    # survives across draw() redraws; swapped out whenever the path changes.
    _preview_img = None
    _preview_path = None
    _preview_pending = None

    @classmethod
    def _release_preview(cls):
        if cls._preview_img is not None:
            try:
                bpy.data.images.remove(cls._preview_img)
            except Exception:
                pass
        cls._preview_img = None
        cls._preview_path = None
        cls._preview_pending = None

    @classmethod
    def _ensure_preview(cls, raw_path: str):
        """Return a loaded Image whose .preview icon draw() can use, or None
        while the load is still in flight.

        The load must NOT happen inside draw(): Blender forbids creating or
        deleting IDs during UI drawing ('Writing to ID classes in this
        context is not allowed'), which made every preview silently fail
        before. Instead we schedule a zero-delay bpy.app.timers callback --
        timers run outside the drawing context -- and the very next redraw
        finds the image ready."""
        if cls._preview_path == raw_path and cls._preview_img is not None:
            return cls._preview_img
        if cls._preview_pending == raw_path:
            return None  # already loading, icon appears on a following frame
        cls._release_preview()
        cls._preview_pending = raw_path

        def _load():
            try:
                img = bpy.data.images.load(raw_path, check_existing=True)
            except Exception:
                img = None
            cls._preview_img = img
            cls._preview_path = raw_path if img is not None else None
            cls._preview_pending = None

        try:
            bpy.app.timers.register(_load, first_interval=0.05)
        except Exception:
            cls._preview_pending = None
        return None

    def invoke(self, context, event):
        return context.window_manager.invoke_props_dialog(self, width=480)

    def draw(self, context):
        layout = self.layout
        wm = context.window_manager

        box = layout.box()
        box.label(text="AI 3D Generation", icon="SHADERFX")
        box.prop(self, "provider")
        box.prop(self, "source_mode")
        if self.source_mode == "TEXT":
            box.prop(self, "prompt")
        else:
            # Adopt a path left by the Paste operator (it can't reach this
            # dialog instance directly). One-shot: consume the key on pickup.
            pasted = wm.get("mcp_clipboard_image")
            if pasted:
                self.image_path = pasted
                del wm["mcp_clipboard_image"]
                type(self)._release_preview()
            row = box.row(align=True)
            row.prop(self, "image_path", text="Image")
            row.operator(MCP_OT_paste_image.bl_idname, text="", icon="PASTEDOWN")
            raw = self.image_path.strip().strip('"')
            if raw and Path(raw).is_file():
                img = self._ensure_preview(raw)
                if img is not None:
                    preview_row = box.row()
                    preview_row.alignment = "CENTER"
                    preview_row.template_icon(icon_value=img.preview.icon_id, scale=6.0)
                elif type(self)._preview_pending is None:
                    box.label(text="Could not load a preview of this file", icon="ERROR")
            elif raw:
                box.label(text="File not found", icon="ERROR")

        layout.separator()
        box_sim = layout.box()
        box_sim.label(text="Mesh Reduction & Budget", icon="MOD_DECIM")
        box_sim.prop(self, "reduction_method")
        if self.reduction_method != "none":
            box_sim.prop(self, "target_vertices")

        layout.separator()
        box_opt = layout.box()
        box_opt.label(text="Placement", icon="TOOL_SETTINGS")
        box_opt.prop(self, "collection_name")

    def execute(self, context):
        # Generation (task create + poll + download) is pure network/file I/O
        # with no bpy calls, so it runs on a background thread instead of
        # blocking Blender's main thread for however long Meshy/Tripo take --
        # a blocking call here previously froze the whole UI, indistinguishable
        # from a crash, for as long as the AI provider took to respond.
        from ..tools.super_import_ops import generate_ai_model_image_job, generate_ai_model_job

        image_file = None
        if self.source_mode == "IMAGE":
            raw = self.image_path.strip().strip('"')
            if not raw:
                self.report({"ERROR"}, "Provide an image path or use Paste to grab one from the clipboard")
                return {"CANCELLED"}
            image_file = Path(raw)
            if not image_file.is_file():
                self.report({"ERROR"}, f"Image file not found: '{raw}'")
                return {"CANCELLED"}
        elif not self.prompt.strip():
            self.report({"ERROR"}, "Please enter a prompt for the 3D model")
            return {"CANCELLED"}

        prompt = self.prompt.strip()
        provider = self.provider.upper()
        # Hand the provider the same budget the local reduction is aiming at,
        # so image-to-3D remeshes on their side instead of shipping a
        # multi-million-triangle raw generation for us to reduce here. "Keep
        # original" opts out, which is exactly what it says on the tin.
        provider_budget = self.target_vertices if self.reduction_method != "none" else None
        self._job = {"done": False, "error": None, "path": None, "credits": None, "status": "Starting..."}

        def worker(job):
            def on_status(text):
                job["status"] = text

            try:
                if image_file is not None:
                    path, credits = generate_ai_model_image_job(
                        provider, str(image_file), status_cb=on_status, target_vertices=provider_budget
                    )
                else:
                    path, credits = generate_ai_model_job(provider, prompt, status_cb=on_status)
                job["path"] = path
                job["credits"] = credits
            except Exception as exc:
                job["error"] = str(exc)
            finally:
                job["done"] = True

        self._thread = threading.Thread(target=worker, args=(self._job,), daemon=True)
        self._thread.start()

        self._area = context.area
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.25, window=context.window)
        wm.modal_handler_add(self)
        return {"RUNNING_MODAL"}

    def modal(self, context, event):
        if event.type == "ESC":
            self._cleanup(context)
            self.report({"WARNING"}, "AI generation cancelled (any in-flight request may still finish on the provider's side)")
            return {"CANCELLED"}

        if event.type != "TIMER":
            return {"PASS_THROUGH"}

        job = self._job
        if self._area:
            self._area.header_text_set(f"{job['status']}  (Esc to cancel)")

        if not job["done"]:
            return {"PASS_THROUGH"}

        self._cleanup(context)

        if job["error"]:
            self.report({"ERROR"}, job["error"])
            return {"CANCELLED"}

        collection = self.collection_name.strip() or f"Generated/{self.provider.capitalize()}"
        result = TOOL_REGISTRY["super_import"].execute({
            "source_type": "FILE",
            "filepath": str(job["path"]),
            "simplifier_tool": self.reduction_method.upper() if self.reduction_method != "none" else "NONE",
            "target_vertices": self.target_vertices,
            "auto_orient": True,
            "normalize_scale": True,
            "target_size": 2.0,
            "ground_to_floor": True,
            "center_xy": True,
            "collection_name": collection,
        })
        if not result.get("success"):
            self.report({"ERROR"}, result.get("message", "Import of generated model failed"))
            return {"CANCELLED"}
        self.report({"INFO"}, f"{result['message']} | {job['credits']}")
        return {"FINISHED"}

    def _cleanup(self, context):
        wm = context.window_manager
        if self._timer:
            wm.event_timer_remove(self._timer)
            self._timer = None
        if self._area:
            self._area.header_text_set(None)
            self._area = None
        type(self)._release_preview()


class VIEW3D_PT_mcp_bridge(bpy.types.Panel):
    bl_label = "MCP Bridge"
    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "MCP Bridge"

    def draw(self, context):
        layout = self.layout
        text, icon = status_text_and_icon()
        layout.label(text=text, icon=icon)

        layout.separator()
        layout.operator(MCP_OT_show_env_info.bl_idname, icon="LOCKED")
        layout.operator(MCP_OT_super_import.bl_idname, icon="IMPORT")
        layout.operator(MCP_OT_ai_generate.bl_idname, icon="SHADERFX")
        layout.operator(MCP_OT_normalize_model.bl_idname, icon="ORIENTATION_GIMBAL")
        layout.operator(MCP_OT_simplify_mesh.bl_idname, icon="MOD_DECIM")
        layout.separator()
        layout.operator(MCP_OT_create_checkpoint.bl_idname, icon="FILE_TICK")
        layout.operator(MCP_OT_restore_checkpoint.bl_idname, icon="FILE_REFRESH")
        layout.operator(MCP_OT_regen_names.bl_idname, icon="WORLD")
        layout.operator(MCP_OT_separate_logical_areas.bl_idname, icon="MESH_DATA")
        layout.separator()
        layout.operator(MCP_OT_verify_tools.bl_idname, icon="TOOL_SETTINGS")

        layout.separator()
        box_tasks = layout.box()
        box_tasks.label(text="Background Tasks", icon="TIME")
        jobs = _recent_jobs(8)
        active = _active_job(jobs)
        if active is None:
            box_tasks.label(text="No active task.", icon="INFO")
        else:
            state, icon = _JOB_STATE_ICONS.get(active.get("status"), (str(active.get("status")), "DOT"))
            row = box_tasks.row()
            row.label(text=f"{active.get('name', '?')} -- {state}", icon=icon)
            op = row.operator(MCP_OT_abort_job.bl_idname, text="Abort", icon="X")
            op.job_id = active["id"]
            # Live lines: the redraw tick refreshes these twice a second
            # while the task runs, so the current task can simply be
            # followed here.
            prog_line = f"{active.get('progress', 0):.0f}%"
            msg = str(active.get("message") or "").strip()
            if msg:
                prog_line += f" -- {msg}"
            box_tasks.label(text=prog_line[:60], icon="DOT")
            op = box_tasks.operator(MCP_OT_show_job_details.bl_idname, text="Follow details...", icon="ZOOM_IN")
            op.job_id = active["id"]
        for job in [j for j in jobs if active is None or j.get("id") != active.get("id")][:6]:
            state, icon = _JOB_STATE_ICONS.get(job.get("status"), (str(job.get("status")), "DOT"))
            row = box_tasks.row()
            created = str(job.get("created", ""))[5:16]  # "09-10 12:31"
            row.label(text=f"{created} {job.get('name', '?')} -- {state}", icon=icon)
            row.label(text=_fmt_job_duration(job.get("duration_seconds")))
            op = row.operator(MCP_OT_show_job_details.bl_idname, text="", icon="ZOOM_IN")
            op.job_id = job["id"]
            if job.get("status") in _JOB_TERMINAL_STATES:
                op = row.operator(MCP_OT_delete_job.bl_idname, text="", icon="TRASH")
                op.job_id = job["id"]
        box_tasks.operator(MCP_OT_prune_old_jobs.bl_idname, icon="TRASH")
        box_tasks.operator(MCP_OT_show_all_tasks.bl_idname, icon="LINENUMBERS_ON")


CLASSES = (
    MCP_SeparatePartItem,
    MCP_OT_show_env_info,
    MCP_OT_super_import,
    MCP_OT_paste_image,
    MCP_OT_ai_generate,
    MCP_OT_normalize_model,
    MCP_OT_simplify_mesh,
    MCP_OT_create_checkpoint,
    MCP_OT_restore_checkpoint,
    MCP_OT_show_rename_result,
    MCP_OT_regen_names,
    MCP_OT_show_separate_result,
    MCP_OT_confirm_separated_parts,
    MCP_OT_separate_logical_areas,
    MCP_OT_verify_tools,
    MCP_OT_abort_job,
    MCP_OT_delete_job,
    MCP_OT_prune_old_jobs,
    MCP_OT_show_job_details,
    MCP_OT_show_all_tasks,
    VIEW3D_PT_mcp_bridge,
)
